import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '나의 투두 리스트',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: TodoListPage(),
    );
  }
}

// == TodoItem class==
class TodoItem {
  String title;
  bool isCompleted;
  bool isImportant;
  DateTime? dueDate; // 마감일 정보

  TodoItem({
    required this.title,
    this.isCompleted = false,
    this.isImportant = false,
    this.dueDate,
  });
}

class TodoListPage extends StatefulWidget {
  @override
  _TodoListPageState createState() => _TodoListPageState();
}

class _TodoListPageState extends State<TodoListPage> {
  List<TodoItem> todos = [];
  TextEditingController textController = TextEditingController();

  // 할 일 추가 함수
  void addTodo() {
    String newTodo = textController.text.trim();

    // 빈 칸이 아닐 때만 추가
    if (newTodo.isNotEmpty) {
      setState(() {
        todos.add(TodoItem(title: newTodo));
      });
      textController.clear();
    }
  }

  // 할 일 삭제 함수
  void deleteTodo(int index) {
    setState(() {
      todos.removeAt(index);
    });
  }

  // 완료 상태 토글
  void toggleTodo(int index) {
    setState(() {
      todos[index].isCompleted = !todos[index].isCompleted;
    });
  }

  // 중요 표시 토글
  void toggleImportant(int index) {
    setState(() {
      todos[index].isImportant = !todos[index].isImportant;
    });
  }

  // 마감일 선택 함수 (캘린더)
  Future<void> setDueDate(int index) async {
    DateTime now = DateTime.now();

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: todos[index].dueDate ?? now,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 5),
    );

    if (picked != null) {
      setState(() {
        todos[index].dueDate = picked;
      });
    }
  }

  // 완료된 항목 전체 삭제
  void deleteCompleted() {
    setState(() {
      todos.removeWhere((todo) => todo.isCompleted);
    });
  }

  // 할 일 제목 수정 함수 (길게 눌렀을 때)
  void editTodoTitle(int index) {
    TextEditingController editController =
        TextEditingController(text: todos[index].title);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('할 일 수정'),
          content: TextField(
            controller: editController,
            decoration: InputDecoration(
              hintText: '새로운 할 일을 입력하세요',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // 닫기
              },
              child: Text('취소'),
            ),
            TextButton(
              onPressed: () {
                String newTitle = editController.text.trim();
                if (newTitle.isNotEmpty) {
                  setState(() {
                    todos[index].title = newTitle;
                  });
                }
                Navigator.pop(context); // 닫기
              },
              child: Text('저장'),
            ),
          ],
        );
      },
    );
  }

  // 완료/미완료 계산 함수
  int get completedCount {
    return todos.where((todo) => todo.isCompleted).length;
  }

  int get UncompletedCount {
    return todos.where((todo) => !todo.isCompleted).length;
  }

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  // 날짜 표시 포맷 (yyyy-mm-dd)
  String _formatDate(DateTime date) {
    String mm = date.month.toString().padLeft(2, '0');
    String dd = date.day.toString().padLeft(2, '0');
    return '${date.year}-$mm-$dd';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Text('나의 투두 리스트'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // 입력 영역
          Container(
            color: Colors.blue,
            padding: EdgeInsets.all(20),
            child: Row(
              children: [
                // 입력창
                Expanded(
                  child: TextField(
                    controller: textController,
                    decoration: InputDecoration(
                      hintText: '할 일을 입력하세요...',
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onSubmitted: (_) => addTodo(), // 엔터 치면 추가
                  ),
                ),
                SizedBox(width: 10),
                // 추가 버튼
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    padding: EdgeInsets.all(15),
                  ),
                  onPressed: addTodo,
                  child: Icon(Icons.add, color: Colors.blue, size: 30),
                ),
              ],
            ),
          ),

          // 통계 영역
          Container(
            padding: EdgeInsets.all(15),
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('전체', todos.length, Colors.blue),
                _buildStatItem('완료', completedCount, Colors.green),
                _buildStatItem('미완료', UncompletedCount, Colors.orange),
                TextButton.icon(
                  onPressed: deleteCompleted,
                  icon: Icon(Icons.delete_forever, color: Colors.red),
                  label: Text(
                    '완료 삭제',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ),

          // 할 일 목록
          Expanded(
            child: todos.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.check_circle_outline,
                            size: 100, color: Colors.grey[300]),
                        SizedBox(height: 20),
                        Text(
                          '할 일이 없습니다!',
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: EdgeInsets.all(10),
                    itemCount: todos.length,
                    itemBuilder: (context, index) {
                      final item = todos[index];

                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 5),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Colors.blue,
                            child: Text(
                              '${index + 1}',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                          title: Text(
                            item.title,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: item.isImportant
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                              decoration: item.isCompleted
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                            ),
                          ),
                          subtitle: item.dueDate == null
                              ? null
                              : Text(
                                  '마감일: ${_formatDate(item.dueDate!)}',
                                  style: TextStyle(
                                    fontSize: 13,
                                    color: Colors.grey[600],
                                  ),
                                ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              // 마감일 설정 버튼
                              IconButton(
                                icon: Icon(Icons.calendar_today),
                                onPressed: () => setDueDate(index),
                              ),
                              // 중요 표시 버튼
                              IconButton(
                                icon: Icon(
                                  item.isImportant
                                      ? Icons.star
                                      : Icons.star_border,
                                ),
                                color: item.isImportant
                                    ? Colors.amber
                                    : Colors.grey,
                                onPressed: () => toggleImportant(index),
                              ),
                              // 삭제 버튼
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () => deleteTodo(index),
                              ),
                            ],
                          ),
                          onTap: () => toggleTodo(index),          // 탭 → 완료 토글
                          onLongPress: () => editTodoTitle(index), // 길게 누름 → 제목 수정
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // 통계 항목 위젯
  Widget _buildStatItem(String label, int count, Color color) {
    return Column(
      children: [
        Text(
          '$count',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(fontSize: 14, color: Colors.grey[600]),
        ),
      ],
    );
  }
}